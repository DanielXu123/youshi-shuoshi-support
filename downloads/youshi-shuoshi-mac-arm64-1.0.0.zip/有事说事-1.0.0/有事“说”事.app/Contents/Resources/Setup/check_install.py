"""Check runtime and model integrity; never reads personal vocabulary/recordings."""
import argparse
import importlib.metadata
import json
import platform
from pathlib import Path
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--runtime-only", action="store_true")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    if platform.system() != "Darwin" or platform.machine() != "arm64":
        raise RuntimeError("此版本需要 Apple Silicon Mac")
    if int(platform.mac_ver()[0].split(".")[0]) < 26:
        raise RuntimeError("此版本需要 macOS 26 或更新")
    if sys.version_info[:2] != (3, 12):
        raise RuntimeError("需要 Python 3.12")
    for line in (root / "requirements.txt").read_text().splitlines():
        if not line or line.startswith("#"):
            continue
        name, version = line.split("==", 1)
        installed = importlib.metadata.version(name)
        if installed != version:
            raise RuntimeError(f"依赖版本不符：{name}，需要 {version}，实际 {installed}")
    import mlx.core as mx
    import mlx_whisper
    from mlx_audio.stt.utils import load_model
    import soundfile
    from opencc import OpenCC
    mx.eval(mx.array([1, 2]).sum())
    print("Python、固定依赖及 Metal 基础运算通过。")
    if not args.runtime_only:
        from download_models import fetch
        manifest = json.loads((root / "models-manifest.json").read_text())
        for model in manifest["models"]:
            for item in model["files"]:
                fetch(root, model, item, "https://hf-mirror.com", verify_only=True)
        print("三个模型文件完整。可以打开 有事“说”事.app；模型首次使用时会预热。")


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(f"安装检查失败：{error}", file=sys.stderr)
        sys.exit(1)
