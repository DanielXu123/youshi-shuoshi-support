#!/bin/bash
set -euo pipefail
SCRIPT_ROOT="$(cd -- "$(dirname -- "$0")" && pwd)"
ROOT="${QUIETTYPE_INSTALL_ROOT:-$SCRIPT_ROOT}"
if [[ "$(uname -s)" != Darwin || "$(uname -m)" != arm64 ]]; then
  echo '此版本需要 Apple Silicon（M 系列）Mac。' >&2; exit 1
fi
MAJOR="$(sw_vers -productVersion | cut -d. -f1)"
if [[ "$MAJOR" -lt 26 ]]; then echo '此版本需要 macOS 26 或更新版本。' >&2; exit 1; fi
mkdir -p "$ROOT/.tools" "$ROOT/.python" "$ROOT/.cache/uv" "$ROOT/Engine/data"
chmod 700 "$ROOT/Engine/data"
UV_VERSION=0.13.4
UV_SHA256=e0b1d4743ce64c55d9f0f4a444afa6b81125680070ee04e853fcd0f6c1ebf8f1
ARCHIVE="${QUIETTYPE_UV_ARCHIVE:-$ROOT/.tools/uv-$UV_VERSION.tar.gz}"
if [[ ! -x "$ROOT/.tools/uv" ]] || [[ "$("$ROOT/.tools/uv" --version)" != "uv $UV_VERSION"* ]]; then
  if [[ ! -f "$ARCHIVE" ]] || [[ "$(shasum -a 256 "$ARCHIVE" | cut -d' ' -f1)" != "$UV_SHA256" ]]; then
    echo "下载官方 uv ${UV_VERSION}（可重复执行恢复下载）…"
    /usr/bin/curl --fail --location --proto '=https' --proto-redir '=https' --continue-at - --retry 5 --retry-delay 3 --connect-timeout 20 \
      --speed-time 60 --speed-limit 1024 \
      "https://github.com/astral-sh/uv/releases/download/$UV_VERSION/uv-aarch64-apple-darwin.tar.gz" \
      --output "$ARCHIVE"
  fi
  if [[ "$(shasum -a 256 "$ARCHIVE" | cut -d' ' -f1)" != "$UV_SHA256" ]]; then
    if [[ "$ARCHIVE" == "$ROOT/.tools/uv-$UV_VERSION.tar.gz" ]]; then
      mv "$ARCHIVE" "$ARCHIVE.invalid-$(date +%s)"
    fi
    echo '安装工具校验失败，异常文件已保留；请重试安装以重新下载。' >&2; exit 1
  fi
  tar -xzf "$ARCHIVE" -C "$ROOT/.tools" --strip-components=1 uv-aarch64-apple-darwin/uv
fi
export UV_PYTHON_INSTALL_DIR="$ROOT/.python"
export UV_CACHE_DIR="$ROOT/.cache/uv"
export UV_NO_MODIFY_PATH=1
export UV_LINK_MODE=copy
export UV_HTTP_TIMEOUT=120
UV="$ROOT/.tools/uv"
PYTHON="$ROOT/Engine/runtime/bin/python"
if [[ ! -x "$PYTHON" ]]; then
  if [[ -e "$ROOT/Engine/runtime/pyvenv.cfg" ]]; then
    echo '现有虚拟环境无法启动；若移动过文件夹，请将 Engine/runtime 移走，再重新安装。' >&2; exit 1
  fi
  "$UV" venv --python 3.12.14 --managed-python "$ROOT/Engine/runtime"
fi
"$PYTHON" -c 'import platform,sys; assert sys.version_info[:2] == (3,12), "需要 Python 3.12"; assert platform.machine() == "arm64", "需要 arm64 Python"'
echo '安装已验证的固定版本依赖…'
"$UV" pip install --python "$PYTHON" --requirement "$SCRIPT_ROOT/requirements.txt"
"$UV" pip check --python "$PYTHON"
"$PYTHON" "$SCRIPT_ROOT/check_install.py" --runtime-only
echo "运行环境已安装到：$ROOT/Engine/runtime"
