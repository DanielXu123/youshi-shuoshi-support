"""Pinned model files with curl resume, size/SHA-256 verification and atomic install."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from urllib.parse import quote, urlsplit

JSON_PROGRESS = False

def report(message, **values):
    print(json.dumps({"message": message, **values}, ensure_ascii=False) if JSON_PROGRESS else message, flush=True)


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def valid(path, item):
    return path.is_file() and path.stat().st_size == item["bytes"] and digest(path) == item["sha256"]


def run_curl(arguments):
    # Stream the normal curl progress while retaining a small diagnostic tail.
    tail = b""
    with subprocess.Popen(arguments, stderr=subprocess.PIPE) as process:
        while chunk := process.stderr.read1(4096):
            if not JSON_PROGRESS:
                sys.stderr.buffer.write(chunk)
                sys.stderr.buffer.flush()
            tail = (tail + chunk)[-8192:]
        status = process.wait()
    if status:
        raise subprocess.CalledProcessError(status, arguments, stderr=tail.decode("utf-8", errors="replace"))


def fetch(root, model, item, endpoint, verify_only=False):
    directory = root / model["path"]
    destination = directory / item["file"]
    if not destination.resolve().is_relative_to(root.resolve()):
        raise ValueError("模型文件路径必须在安装目录内")
    report(f"校验：{model['id']}/{item['file']}", phase="checking", model=model['id'], file=item['file'])
    if valid(destination, item):
        report(f"已校验：{model['id']}/{item['file']}", phase="complete")
        return
    if verify_only:
        raise RuntimeError(f"文件缺失或校验失败：{destination}")
    directory.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        backup = destination.with_name(destination.name + f".invalid-{time.time_ns()}")
        destination.rename(backup)
        report(f"保留原来的异常文件：{backup}")
    partial = destination.with_name(destination.name + ".part")
    if partial.exists() and partial.stat().st_size > item["bytes"]:
        partial.rename(partial.with_name(partial.name + f".invalid-{time.time_ns()}"))
    # A previous run may have finished downloading but stopped before rename.
    if not valid(partial, item):
        if partial.exists() and partial.stat().st_size == item["bytes"]:
            partial.rename(partial.with_name(partial.name + f".invalid-{time.time_ns()}"))
        url = f"{endpoint}/{model['repository']}/resolve/{model['revision']}/{quote(item['file'], safe='/')}"
        report(f"下载：{model['id']}/{item['file']} ({item['bytes']:,} bytes)", phase="download", model=model['id'], file=item['file'])
        arguments = [
            "/usr/bin/curl", "--fail", "--location", "--proto", "=https", "--proto-redir", "=https", "--continue-at", "-", "--retry", "6", "--retry-delay", "3",
            "--connect-timeout", "20", "--speed-time", "60", "--speed-limit", "1024",
            "--output", str(partial), url,
        ]
        try:
            run_curl(arguments)
        except subprocess.CalledProcessError as error:
            details = (error.stderr or "").lower()
            if error.returncode != 33 and "support byte ranges" not in details:
                raise
            # Some mirror redirects serve small metadata without Range support.
            # Restart this incomplete download, then still require the same hash.
            report("镜像不支持此文件的断点续传，正在从头重试该文件…")
            partial.unlink(missing_ok=True)
            run_curl(arguments)
    if not valid(partial, item):
        if partial.exists() and partial.stat().st_size == item["bytes"]:
            partial.rename(partial.with_name(partial.name + f".invalid-{time.time_ns()}"))
        raise RuntimeError(f"文件校验未通过，未安装：{destination}；重新执行即可重试。")
    os.replace(partial, destination)
    report(f"下载并校验完成：{destination}", phase="complete")


def main():
    global JSON_PROGRESS
    parser = argparse.ArgumentParser(description="下载三个 有事“说”事 模型到本文件夹的相对位置")
    parser.add_argument("--only", choices=["turbo", "large-v3", "qwen3"], help="只下载指定模型；默认三个全部下载")
    parser.add_argument("--verify-only", action="store_true", help="仅校验已有文件，不访问网络")
    parser.add_argument("--root", type=Path, help="App 指定的用户数据目录")
    parser.add_argument("--manifest", type=Path, help="App 内置的固定版本清单")
    parser.add_argument("--json-progress", action="store_true")
    args = parser.parse_args()
    JSON_PROGRESS = args.json_progress
    root = (args.root or Path(__file__).resolve().parent).resolve()
    root.mkdir(parents=True, exist_ok=True)
    manifest = json.loads((args.manifest or root / "models-manifest.json").read_text())
    endpoint = os.environ.get("HF_ENDPOINT", "https://hf-mirror.com").rstrip("/")
    if urlsplit(endpoint).scheme != "https":
        raise ValueError("模型源必须使用 HTTPS")
    with (root / ".model-download.lock").open("a") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError("另一个模型下载仍在运行，请等待其完成。") from None
        selected = [m for m in manifest["models"] if not args.only or m["id"] == args.only]
        for model in selected:
            for item in model["files"]:
                fetch(root, model, item, endpoint, args.verify_only)
        report("所选模型全部通过大小和 SHA-256 校验。", phase="ready")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, RuntimeError, subprocess.CalledProcessError) as error:
        print(f"下载未完成：{error}", file=sys.stderr)
        sys.exit(1)
